document.addEventListener('DOMContentLoaded', function() {
    const btnCerrarSesion = document.getElementById('btnCerrarSesion');
    btnCerrarSesion.addEventListener('click', function() {
        // Aquí puedes añadir el código para cerrar la sesión
        alert('Implementar código para cerrar sesión');
    });
});
