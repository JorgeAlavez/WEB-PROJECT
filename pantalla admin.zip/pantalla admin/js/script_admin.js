document.addEventListener('DOMContentLoaded', function() {
    const ctx1 = document.getElementById('productosMasVendidos').getContext('2d');
    const ctx2 = document.getElementById('productosMenosStock').getContext('2d');
    const ctx3 = document.getElementById('ingresosPorProducto').getContext('2d');
    const ctx4 = document.getElementById('categoriasMasVendidas').getContext('2d');
    const ctx5 = document.getElementById('stockDisponible').getContext('2d');
    const ctx6 = document.getElementById('ingresosGlobales').getContext('2d');

    const productosMasVendidosData = {
        labels: ['Producto A', 'Producto B', 'Producto C', 'Producto D'],
        datasets: [{
            label: 'Ventas',
            /* data es para poner los datos de los productos */
            data: [12, 19, 3, 5],
            backgroundColor: 'rgba(75, 192, 192, 0.2)',
            borderColor: 'rgba(75, 192, 192, 1)',
            borderWidth: 1
        }]
    };

    const productosMenosStockData = {
        labels: ['Producto E', 'Producto F', 'Producto G', 'Producto H'],
        datasets: [{
            label: 'Stock',
            data: [2, 3, 5, 1],
            backgroundColor: 'rgba(255, 99, 132, 0.2)',
            borderColor: 'rgba(255, 99, 132, 1)',
            borderWidth: 1
        }]
    };

    const ingresosPorProductoData = {
        labels: ['Producto A', 'Producto B', 'Producto C', 'Producto D'],
        datasets: [{
            label: 'Ingresos',
            data: [1200, 1500, 800, 2000],
            backgroundColor: 'rgba(54, 162, 235, 0.2)',
            borderColor: 'rgba(54, 162, 235, 1)',
            borderWidth: 1
        }]
    };

    const categoriasMasVendidasData = {
        labels: ['Electrónica', 'Ropa', 'Libros', 'Juguetes'],
        datasets: [{
            label: 'Categorías',
            data: [30, 50, 20, 10],
            backgroundColor: [
                'rgba(255, 159, 64, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 99, 132, 0.2)'
            ],
            borderColor: [
                'rgba(255, 159, 64, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 99, 132, 1)'
            ],
            borderWidth: 1
        }]
    };

    const stockDisponibleData = {
        labels: ['Producto I', 'Producto J', 'Producto K', 'Producto L'],
        datasets: [{
            label: 'Stock',
            data: [50, 20, 30, 15],
            backgroundColor: 'rgba(255, 206, 86, 0.2)',
            borderColor: 'rgba(255, 206, 86, 1)',
            borderWidth: 1
        }]
    };

    const ingresosGlobalesData = {
        labels: ['Enero', 'Febrero', 'Marzo', 'Abril'],
        datasets: [{
            label: 'Ingresos Globales',
            data: [5000, 7000, 8000, 6000],
            backgroundColor: 'rgba(153, 102, 255, 0.2)',
            borderColor: 'rgba(153, 102, 255, 1)',
            borderWidth: 1,
            fill: true
        }]
    };

    new Chart(ctx1, {
        type: 'bar',
        data: productosMasVendidosData,
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    new Chart(ctx2, {
        type: 'bar',
        data: productosMenosStockData,
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    new Chart(ctx3, {
        type: 'bar',
        data: ingresosPorProductoData,
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    new Chart(ctx4, {
        type: 'pie',
        data: categoriasMasVendidasData,
        options: {
            responsive: true
        }
    });

    new Chart(ctx5, {
        type: 'bar',
        data: stockDisponibleData,
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    new Chart(ctx6, {
        type: 'line',
        data: ingresosGlobalesData,
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
});

